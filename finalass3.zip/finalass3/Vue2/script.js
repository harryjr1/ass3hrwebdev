
// Define size related variables
const dimension = d3
  .select(".visualisation")
  .node()
  .parentNode.getBoundingClientRect();
const margin = 10;
const width = dimension.width;
let height = dimension.height;
const aspect = width / height;
const rotate = -9.9;
let scaleFactor = 70;
let translateFactor = 1.5;
if (width < 400) {
  scaleFactor = 20;
  translateFactor = 1.7;
}
if (aspect < 2/3) {
  height = width * 1/3
}

const zoom = d3
  .zoom()
  .scaleExtent([-15, 30])
  .translateExtent([
    [0, 0],
    [width, height]
  ])
  .on("zoom", function () {
    d3.select("g").attr("transform", d3.event.transform);
  });

// Add the core svg block
const svg = d3
  .select(".visualisation")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .attr("preserveAspectRatio", "xMinYMin meet")
  .attr("viewBox", `0 0 ${width} ${height}`)
  .call(zoom);

const globe = svg.append("g");

const tooltip = d3
  .select(".visualisation")
  .append("div")
  .attr("class", "hidden tooltip");

const projection = d3
  .geoMercator()
  .rotate([rotate, 0])
  .scale(scaleFactor * aspect / 1.25)
  .translate([width / 2, height / translateFactor ]);

let geoPath = d3.geoPath().projection(projection);


//const colorScale = d3.scaleSqrt(["#440154", "#21918c", "#fde725"]);
const colorScale = d3.scaleSqrt(["#ddd", "#777" ,"#000"]);

const map = {};

Promise.all([
  d3.json(
    "https://gist.githubusercontent.com/eetuko/4535086c3fabe76a173b432c44b254c6/raw/60929b4cbf24f0e14daa62c29bf0af7b16aa5cc5/world.topojson"
  ),
  d3.json("https://corona.lmao.ninja/v3/covid-19/countries")
]).then(function ([o_shapes, data]) {
  var shapes = topojson.feature(o_shapes, "world");
  // save in a global context and remove antarctic.
  map.features = shapes.features.filter((d) => d.properties.ISO_A3 !== "ATA");
  map.data = data;
  map.metric = d3.select("#metrics").property("value");

  selectData();
  colorScale.domain([0, 
                     d3.median(map.data, (d) => d[map.metric]),
                     d3.max(map.data, (d) => d[map.metric])]);

  draw();
  drawLegend();

  d3.select("#metrics").on("change", change);
});

function selectData() {
  map.features.forEach((d) => {
    var entry1 = map.data.filter(
      (t) => t.countryInfo.iso3 == d.properties.ISO_A3
    )[0];
    if (entry1) {
      d.properties.dataPoint = entry1[map.metric];
      d.properties.country = entry1.country;
    } else {
      d.properties.dataPoint = 0;
      d.properties.country = "Unknown";
    }
  });
}

function draw() {
  globe.selectAll("path.country").remove();
  globe
    .selectAll("path.country")
    .data(map.features)
    .enter()
    .append("path")
    .attr("class", "country")
    .attr("d", geoPath)
    .style("fill", (d) => colorScale(d.properties.dataPoint))
    .on("mousemove", function (d) {
      tooltip
        .classed("hidden", false)
        .html(
          "<h6>" +
            d.properties.country +
            ": " +
            d.properties.dataPoint +
            "</h6>"
        )
        .attr(
          "style",
          "left:" +
            (d3.event.pageX + 15) +
            "px; top:" +
            (d3.event.pageY + 20) +
            "px"
        );
    })
    .on("mouseout", function () {
      tooltip.classed("hidden", true);
    });
}

function drawLegend() {
  svg.select(".legendLinear").remove();
  let heightFactor = 0.8;
  if (width < 400) {
    heightFactor = 0.2;
  }
  svg
    .append("g")
    .attr("class", "legendLinear")
    .attr("transform", "translate(10," + (height * heightFactor) + ")");

  var shapeWidth = 40,
    cellCount = 5,
    shapePadding = 2,
    legendTitle =
      map.metric.replace("PerOneMillion", "") + " per million population: ";

  var legendLinear = d3
    .legendColor()
    .title(legendTitle)
    .shape("rect")
    .shapeWidth(shapeWidth)
    .cells(cellCount)
    .labelFormat(d3.format(".3s"))
    .orient("horizontal")
    .shapePadding(shapePadding)
    .scale(colorScale);
  
   svg
      .select(".legendLinear")
      .append("rect")
      .attr("class", "legendBackground")
      .attr("x", -5)
      .attr("y", -22)
      .attr("opacity", 0.9)
      .attr("rx", 8)
      .attr("ry", 8)
      .attr("width", legendTitle.length * 7.4)
      .attr("height", 80)
      .classed("hidden", true);

  
    svg.select(".legendLinear")
       .call(legendLinear)
       .classed("hidden", true);
  
    if (width < 400) {
      d3.select(".smallLegend")
        .on("mouseover", () => {
          svg.selectAll(".legendBackground,.legendLinear")
            .classed("hidden", false);
        })
        .on("mouseout", () => {
         svg.selectAll(".legendBackground,.legendLinear")
            .classed("hidden", true);
      })
      } else {
        svg.selectAll(".legendBackground,.legendLinear")
           .classed("hidden", false);
    }
}

function change() {
  map.metric = d3.select("#metrics").property("value");
  selectData();
  colorScale.domain([0, 
                     d3.median(map.data, (d) => d[map.metric]),
                     d3.max(map.data, (d) => d[map.metric])]);
  draw();
  drawLegend();
}

d3.select(window).on("resize", function () {
  var targetWidth = d3
    .select(".visualisation")
    .node()
    .parentNode.getBoundingClientRect();
  svg.attr("width", targetWidth);
  svg.attr("height", targetWidth / aspect);
  svg.attr("viewBox", `0 0 ${width} ${height}`);
});


const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav-links");
const links = document.querySelectorAll(".nav-links li");

hamburger.addEventListener('click', ()=>{
   //Animate Links
    navLinks.classList.toggle("open");
    links.forEach(link => {
        link.classList.toggle("fade");
    });

    //Hamburger Animation
    hamburger.classList.toggle("toggle");
});